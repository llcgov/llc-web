<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-4 col-md-offset-4">
    <div class="login-panel panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">Please Sign In</h3>
      </div>
      <div class="panel-body">
        <form action="<?php echo e(route('login')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <fieldset>
            <div class="form-group">
              <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus value=" <?php echo e(old('email')); ?> ">
              <?php if($errors->has('email')): ?>
              <span class="help-block"><?php echo e($errors->first('email')); ?></span>
              <?php endif; ?>
            </div>
            <div class="form-group">
              <input class="form-control" placeholder="Password" name="password" type="password" value="">
              <?php if($errors->has('password')): ?>
              <span class="help-block"><?php echo e($errors->first('password')); ?></span>
              <?php endif; ?>
            </div>
            <div class="checkbox">
              <label>
                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> value="1"> Remember Me
              </label>
            </div>
            <!-- Change this to a button or input when using this as a form -->
            <button type="submit" class="btn btn-lg btn-success btn-block">Login</button>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-lg btn-primary btn-block">Register</a>
          </fieldset>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RON\Desktop\Web Project\lapu-lapu\resources\views/auth/login.blade.php ENDPATH**/ ?>